"""
saeb_flow.py  SE(3)T^n Averaged Energy-Based Flow (SAEB-Flow)

Replaces cpu_torsional_flow.py with a theoretically correct implementation.

Key design decisions vs. the old Kabsch-based F-SE3:

 Old F-SE3 (Kabsch)         SAEB-Flow                                    

 SE(3)^K snap projection    FK Jacobian geodesic integration             
 K-Means fragmentation      RDKit chemical bond prior (hard, correct)    
 SVD at every step          SVD only at initialisation (precomputed)     
 SO(3) log map   singul.  Torus wrap operator:  mod 2 (no singul.)  
 KKT post-hoc coupling      Coupling is internal to FK Jacobian          
 Uniform atom weighting     Confidence-weighted centroid (from CBSF)     
 Independent fragment RMSD  Fibre-bundle joint loss (vectorised)         


Public API (backward-compatible with cpu_torsional_flow.py callers):
  get_rigid_fragments(pos_native, n_fragments)    labels  [legacy wrapper]
  sample_torsional_prior(pos_native, labels, ...)  (B,N,3) [legacy wrapper]
  apply_fragment_kabsch(pos_pred, pos_ref, labels)  (B,N,3) [REPLACED]
  compute_torsional_joint_loss(pos_proj, pos_ref, labels)  scalar [upgraded]

New SAEB-Flow API:
  build_fiber_bundle(pos_native, x_L, mol)   FiberBundle
  saeb_harmonic_prior(fb, p_center, B, )    (B,N,3)
  so3_averaged_target(pos_pred, pos_native, t)  (B,N,3) velocities
  apply_saeb_step(pos, fb, v_trans, v_tors, dt)  (B,N,3)
  energy_guided_interpolant(pos0, pos1, t, phys_fn)  (B,N,3)
"""

import torch
import torch.nn.functional as F
import numpy as np
from typing import Optional, Tuple, List, NamedTuple
from dataclasses import dataclass, field
from scipy.spatial.transform import Rotation


# 
# Data structures
# 

@dataclass
class FiberBundle:
    """
    Describes the SE(3) _ T^n fibre-bundle topology of a ligand.

    Attributes
    ----------
    n_atoms          : int
    rotatable_bonds  : list of (i, j) int pairs  only chemically rotatable bonds
    downstream_masks : (n_bonds, N) bool  True for atoms downstream of bond k
    fragment_labels  : (N,) long  spectral cluster index (legacy compat)
    pivot_atoms      : (n_bonds,) int  the 'anchor' atom of each bond axis
    """
    n_atoms:          int
    rotatable_bonds:  List[Tuple[int, int]]
    downstream_masks: torch.Tensor          # (n_bonds, N)
    fragment_labels:  torch.Tensor          # (N,)     legacy compat
    pivot_atoms:      List[int]
    device:           torch.device = field(default_factory=lambda: torch.device('cpu'))

    @property
    def n_bonds(self) -> int:
        return len(self.rotatable_bonds)


# 
# 1. Rotatable bond detection  (chemical hard prior)
# 

def _get_rotatable_bonds_rdkit(mol) -> List[Tuple[int, int]]:
    """Use RDKit SMARTS to detect chemically rotatable bonds."""
    from rdkit import Chem
    rot_bond_smarts = (
        "[!$([NH]!@C(=O))&!D1&!$(*#*)]-&!@"
        "[!$([NH]!@C(=O))&!D1&!$(*#*)]"
    )
    pattern = Chem.MolFromSmarts(rot_bond_smarts)
    if pattern is None:
        return []
    matches = mol.GetSubstructMatches(pattern)
    return [(int(m[0]), int(m[1])) for m in matches]


def _get_rotatable_bonds_spectral(
    pos_native: torch.Tensor,
    n_fragments: int,
) -> Tuple[List[Tuple[int, int]], torch.Tensor]:
    """
    Fallback when RDKit is unavailable.
    Uses spectral clustering to identify fragments, then returns the
    inter-fragment edges with shortest inter-atom distance as pseudo-bonds.
    Returns (bond_list, fragment_labels).
    """
    device = pos_native.device
    N = pos_native.shape[0]

    if N < 4:
        labels = torch.zeros(N, dtype=torch.long, device=device)
        return [], labels

    # Spectral clustering (identical to original get_rigid_fragments)
    dist = torch.cdist(pos_native, pos_native)
    W    = torch.exp(-dist ** 2 / (2 * 1.5 ** 2))
    D    = W.sum(dim=-1)
    L    = torch.eye(N, device=device) - W / D.unsqueeze(-1)
    L_sym = (L + L.T) / 2
    try:
        _, eigvecs = torch.linalg.eigh(L_sym)
    except Exception:
        _, eigvecs = torch.linalg.eig(L_sym)
        eigvecs = eigvecs.real

    features  = eigvecs[:, :n_fragments]
    indices   = torch.linspace(0, N - 1, n_fragments).long()
    centroids = features[indices].clone()
    labels    = torch.zeros(N, dtype=torch.long, device=device)

    for _ in range(20):
        dists  = torch.cdist(features, centroids)
        labels = dists.argmin(dim=-1)
        for i in range(n_fragments):
            if (labels == i).sum() > 0:
                centroids[i] = features[labels == i].mean(dim=0)

    # Find inter-fragment bonds: shortest distance between different-fragment atoms
    diff_lbl = labels.unsqueeze(0) != labels.unsqueeze(1)
    close    = (dist < 1.8) & diff_lbl

    bonds = []
    seen  = set()
    for i in range(N):
        for j in range(i + 1, N):
            if close[i, j] and (i, j) not in seen:
                bonds.append((i, j))
                seen.add((i, j))

    return bonds, labels


def _build_downstream_masks(
    N: int,
    rotatable_bonds: List[Tuple[int, int]],
    bond_graph: Optional[List[List[int]]] = None,
    dist_matrix: Optional[torch.Tensor] = None,
    device: torch.device = torch.device('cpu'),
) -> Tuple[torch.Tensor, List[int]]:
    """
    For each bond (ij), compute the set of atoms reachable from j
    when bond (i,j) is cut.  Uses BFS on the bond adjacency graph.

    If `bond_graph` is not provided, falls back to proximity (< 1.65 ).
    Returns:
      masks: (n_bonds, N) bool
      pivots: list of pivot atom index per bond (= atom i)
    """
    n_bonds = len(rotatable_bonds)

    # Build adjacency from distance matrix if no explicit graph
    if bond_graph is None and dist_matrix is not None:
        d_np = dist_matrix.cpu().numpy()
        bond_graph = [[] for _ in range(N)]
        for a in range(N):
            for b in range(a + 1, N):
                if d_np[a, b] < 1.65:
                    bond_graph[a].append(b)
                    bond_graph[b].append(a)
    elif bond_graph is None:
        bond_graph = [[] for _ in range(N)]

    masks  = torch.zeros(n_bonds, N, dtype=torch.bool, device=device)
    pivots = []

    for k, (i, j) in enumerate(rotatable_bonds):
        # BFS from j, excluding i
        visited = set()
        queue   = [j]
        visited.add(j)
        visited.add(i)   # cut the bond by excluding i
        while queue:
            node = queue.pop(0)
            for nb in bond_graph[node]:
                if nb not in visited:
                    visited.add(nb)
                    queue.append(nb)
        downstream = list(visited - {i})
        if downstream:
            masks[k, downstream] = True
        pivots.append(i)

    return masks, pivots


def build_fiber_bundle(
    pos_native: torch.Tensor,          # (N, 3)
    x_L:        Optional[torch.Tensor] = None,   # (N, D) atom features
    mol         = None,                 # optional RDKit mol
    n_fragments: int = 4,
) -> FiberBundle:
    """
    Main entry point: build the FiberBundle topology for a ligand.
    Uses RDKit if available and mol is provided, else spectral fallback.
    """
    device = pos_native.device
    N      = pos_native.shape[0]
    dist   = torch.cdist(pos_native, pos_native)

    #  bond detection 
    rotatable_bonds: List[Tuple[int, int]] = []
    fragment_labels  = torch.zeros(N, dtype=torch.long, device=device)

    if mol is not None:
        try:
            rotatable_bonds = _get_rotatable_bonds_rdkit(mol)
        except Exception as e:
            from logging import getLogger
            getLogger("SAEBFlow").warning(f" [SAEB-Flow] RDKit bond detection resonance failed: {e}. Falling back to spectral.")

    if not rotatable_bonds:
        rotatable_bonds, fragment_labels = _get_rotatable_bonds_spectral(
            pos_native, n_fragments
        )
    else:
        # Derive labels from connected components after cutting rotatable bonds
        # (simplified: use spectral as proxy for labels)
        _, fragment_labels = _get_rotatable_bonds_spectral(pos_native, n_fragments)

    #  downstream masks 
    downstream_masks, pivot_atoms = _build_downstream_masks(
        N=N,
        rotatable_bonds=rotatable_bonds,
        dist_matrix=dist,
        device=device,
    )

    return FiberBundle(
        n_atoms          = N,
        rotatable_bonds  = rotatable_bonds,
        downstream_masks = downstream_masks,
        fragment_labels  = fragment_labels,
        pivot_atoms      = pivot_atoms,
        device           = device,
    )


# 
# 2. Harmonic prior sampling
# 

def saeb_harmonic_prior(
    fb:          FiberBundle,
    pos_native:  torch.Tensor,   # (N, 3)  reference geometry
    p_center:    torch.Tensor,   # (3,)    pocket centre
    B:           int,
    noise_scale: float = 5.0,
) -> torch.Tensor:
    """
    Harmonic prior that:
      1. Preserves internal rigid geometry (keeps bond lengths/angles intact)
      2. Randomises ONLY global SO(3) rotation + T^n torsion angles
      3. Places the ligand at the pocket centre

    This replaces `sample_torsional_prior` with a chemically correct version.
    """
    device = pos_native.device
    N      = pos_native.shape[0]
    com    = pos_native.mean(dim=0)
    pos_c  = pos_native - com        # centred reference geometry

    batch = []
    for _ in range(B):
        pos_b = pos_c.clone()

        #  1. Randomise torsion angles (T^n component) 
        if fb.n_bonds > 0:
            for k, (i, j) in enumerate(fb.rotatable_bonds):
                mask = fb.downstream_masks[k]
                if mask.sum() < 1:
                    continue

                # Random torsion angle drawn uniformly from [-, ]
                theta = (torch.rand(1, device=device) * 2 - 1) * np.pi * noise_scale / 5.0

                # Rotation axis = unit vector along bond
                axis  = pos_b[j] - pos_b[i]
                axis  = axis / (axis.norm() + 1e-8)

                # Rodrigues rotation of downstream atoms around pivot i
                pivot     = pos_b[i]
                rel_pos   = pos_b[mask] - pivot
                cos_t     = theta.cos().item()
                sin_t     = theta.sin().item()
                ax        = axis.cpu().numpy()
                K         = np.array([[0, -ax[2], ax[1]],
                                       [ax[2], 0, -ax[0]],
                                       [-ax[1], ax[0], 0]])
                R_k       = (np.eye(3) * cos_t +
                             (1 - cos_t) * np.outer(ax, ax) +
                             sin_t * K)
                R_t       = torch.tensor(R_k, dtype=torch.float32, device=device)
                pos_b_updated = pos_b.clone()
                pos_b_updated[mask] = rel_pos @ R_t.T + pivot

                pos_b = pos_b_updated

        #  2. Global SO(3) rotation (SE(3) base component) 
        R_global = torch.tensor(
            Rotation.random().as_matrix(), dtype=torch.float32, device=device
        )
        pos_b = pos_b @ R_global.T

        #  3. Translate to pocket (+ small Gaussian noise) 
        t_noise = torch.randn(3, device=device) * noise_scale * 0.1
        t_vec   = p_center - pos_b.mean(dim=0) + t_noise
        pos_b   = pos_b + t_vec

        batch.append(pos_b)

    return torch.stack(batch, dim=0)   # (B, N, 3)


# 
# 3. SO(3)-averaged flow target  (no SVD during training)
# 

def so3_averaged_target(
    pos_pred:   torch.Tensor,   # (B, N, 3)
    pos_native: torch.Tensor,   # (N, 3) or (B, N, 3)
    t:          float,
) -> torch.Tensor:
    """
    SO(3)-Averaged Flow Matching target (NVIDIA ICML 2025 insight).

    For the conditional docking task (x1 = fixed crystal structure),
    the Haar-averaged target decomposes naturally:
      - Translation component: centroid difference (exact)
      - Rotation component:    centroid-free direct difference
        (averaging over SO(3) leaves zero net rotation bias,
        so the model learns the correct rotation from context)

    Critically: NO SVD, NO Kabsch alignment needed during training.
    The model learns rotational alignment implicitly from the ensemble.

    Returns: v_target (B, N, 3)
    """
    B, N, _ = pos_pred.shape
    dt_inv   = 1.0 / (1.0 - t + 1e-3)

    if pos_native.dim() == 2:
        pos_nat = pos_native.unsqueeze(0).expand(B, -1, -1)
    else:
        pos_nat = pos_native

    # Centroids
    c_pred = pos_pred.mean(dim=1, keepdim=True)   # (B, 1, 3)
    c_nat  = pos_nat.mean(dim=1, keepdim=True)     # (B, 1, 3)

    # Translation velocity: centroid difference (exact Haar average)
    v_trans = (c_nat - c_pred) * dt_inv            # (B, 1, 3)

    # Shape velocity: centred direct difference
    # (The SO(3) Haar average of R @ x_centred = 0, so the "averaged"
    #  shape velocity is the direct centred difference, unbiased by rotation.)
    v_shape = (pos_nat - c_nat - (pos_pred - c_pred)) * dt_inv   # (B, N, 3)

    return v_trans + v_shape   # (B, N, 3)


# 
# 4. Torus-safe torsion velocity
# 

def torus_flow_velocity(
    theta_pred:   torch.Tensor,   # (B, n_bonds)
    theta_native: torch.Tensor,   # (n_bonds,) or (B, n_bonds)
    t:            float,
) -> torch.Tensor:
    """
    Velocity on T^n = (S)^n that avoids the  singularity of log_SO3.

    Uses the 'shortest arc' wrap operator:
       = ((_native - _pred + ) mod 2) -    (-, ]
    This is always well-defined (no arccos, no SVD, no NaN at =).

    Returns: v_tors (B, n_bonds)
    """
    if theta_native.dim() == 1:
        theta_nat = theta_native.unsqueeze(0).expand_as(theta_pred)
    else:
        theta_nat = theta_native

    delta     = theta_nat - theta_pred
    delta_wrapped = ((delta + np.pi) % (2 * np.pi)) - np.pi   #  (-, ]
    return delta_wrapped / (1.0 - t + 1e-3)


# 
# 5. FK Jacobian (precomputed, inference-time only)
# 

def precompute_fk_jacobian(
    pos:  torch.Tensor,   # (B, N, 3) or (N, 3)
    fb:   FiberBundle,
) -> torch.Tensor:
    """
    Computes batched FK Jacobian J  R^(B, N, 3, 6+n_bonds).
    """
    if pos.dim() == 2:
        pos = pos.unsqueeze(0)
    
    B, N, _ = pos.shape
    device  = fb.device
    n       = fb.n_bonds
    dof     = 6 + n

    # Center positions for consistent global rotation Jacobian
    com = pos.mean(dim=1, keepdim=True)
    pos_centered = pos - com

    J = torch.zeros(B, N, 3, dof, device=device)

    # Translation: pos_i / t = I
    J[:, :, 0, 0] = 1.0
    J[:, :, 1, 1] = 1.0
    J[:, :, 2, 2] = 1.0

    # Global rotation: pos_i /  =   (pos_i - com)
    # Corrected signs for   r:
    # For _x: [0, -rz, ry]
    J[:, :, 1, 3] = -pos_centered[:, :, 2]
    J[:, :, 2, 3] = pos_centered[:, :, 1]
    # For _y: [rz, 0, -rx]
    J[:, :, 0, 4] = pos_centered[:, :, 2]
    J[:, :, 2, 4] = -pos_centered[:, :, 0]
    # For _z: [-ry, rx, 0]
    J[:, :, 0, 5] = -pos_centered[:, :, 1]
    J[:, :, 1, 5] = pos_centered[:, :, 0]

    # Torsional: pos_i / _k = axis_k  (pos_i - pivot_k)
    for k, (bi, bj) in enumerate(fb.rotatable_bonds):
        mask = fb.downstream_masks[k]   # (N,)
        if mask.any():
            pivots = pos[:, bi, :].unsqueeze(1)    # (B, 1, 3)
            axes   = pos[:, bj, :] - pos[:, bi, :]  # (B, 3)
            axes   = axes / (axes.norm(dim=-1, keepdim=True) + 1e-8)
            
            # Note: torsion pivot is independent of global centroid, so subtract pivot as before
            rel_pos = pos[:, mask, :] - pivots      # (B, n_mask, 3) 
            
            # Cross product (B, n_mask, 3)
            ax, ay, az = axes[:, 0], axes[:, 1], axes[:, 2]
            rx, ry, rz = rel_pos[:, :, 0], rel_pos[:, :, 1], rel_pos[:, :, 2]
            
            J[:, mask, 0, 6 + k] = ay.unsqueeze(1) * rz - az.unsqueeze(1) * ry
            J[:, mask, 1, 6 + k] = az.unsqueeze(1) * rx - ax.unsqueeze(1) * rz
            J[:, mask, 2, 6 + k] = ax.unsqueeze(1) * ry - ay.unsqueeze(1) * rx
            
    return J   # (N, 3, 6+n)


# 
# 6. Fibre-bundle geodesic step  (replaces apply_fragment_kabsch)
# 

def apply_saeb_step(
    pos:     torch.Tensor,    # (B, N, 3) current positions
    fb:      FiberBundle,
    v_cart:  torch.Tensor,    # (B, N, 3) Cartesian velocity
    dt:      float,
    J:       Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """
    Fibre-bundle geodesic integration step (Batched v96.3).
    """
    B, N, _ = pos.shape
    device   = fb.device

    if J is None:
        J = precompute_fk_jacobian(pos, fb)   # (B, N, 3, dof)

    # Project Cartesian velocities  fibre bundle velocities
    # We use torch.linalg.lstsq for a numerically stable batched solution.
    # Solve J_flat @ q_dot = v_flat  for q_dot
    dof = J.shape[3]
    J_flat = J.view(B, N * 3, dof)
    v_flat  = v_cart.view(B, N * 3, 1)                      # (B, 3N, 1)
    
    # lstsq expects tensors (B, M, N) and (B, M, K)
    # It returns a named tuple; we want the .solution
    # Stable Pseudo-Inverse via rcond=1e-3 to prevent coordinate 'fly-away'
    q_dot_sol = torch.linalg.lstsq(J_flat, v_flat, rcond=1e-3).solution   # (B, dof, 1)
    q_dot     = q_dot_sol.squeeze(-1)                       # (B, dof)

    #  Integrate in fibre bundle space 
    # Global translation update
    delta_t  = q_dot[:, 0:3] * dt

    # Global rotation update via Rodrigues
    omega    = q_dot[:, 3:6] * dt
    angle    = omega.norm(dim=-1, keepdim=True).clamp(min=1e-8)
    axis     = omega / angle

    cos_a    = torch.cos(angle).unsqueeze(-1)
    sin_a    = torch.sin(angle).unsqueeze(-1)

    # Batched cross-product matrix K
    x_rot, y_rot, z_rot = axis[:, 0], axis[:, 1], axis[:, 2]
    K = torch.zeros(B, 3, 3, device=device)
    K[:, 0, 1] = -z_rot; K[:, 0, 2] =  y_rot
    K[:, 1, 0] =  z_rot; K[:, 1, 2] = -x_rot
    K[:, 2, 0] = -y_rot; K[:, 2, 1] =  x_rot
    
    K2 = torch.bmm(K, K)
    I  = torch.eye(3, device=device).unsqueeze(0).expand(B, -1, -1)
    R  = I + sin_a * K + (1 - cos_a) * K2            # (B, 3, 3)

    # Apply global rotation about centroid
    com      = pos.mean(dim=1, keepdim=True)           # (B, 1, 3)
    pos_rot  = torch.bmm(pos - com, R.transpose(1, 2)) + com   # (B, N, 3)

    # Apply global translation
    pos_new  = pos_rot + delta_t.unsqueeze(1)          # (B, N, 3)

    #  Apply torsion updates 
    if fb.n_bonds > 0 and dof > 6:
        dtheta = q_dot[:, 6:] * dt                     # (B, n_bonds)

        for k, (bi, bj) in enumerate(fb.rotatable_bonds):
            mask = fb.downstream_masks[k]              # (N,) bool
            if mask.sum() == 0:
                continue

            # Batched Sequential Update
            # We must update positions for the entire batch sequentially per bond
            # to ensure that downstream pivots/axes are always current.
            theta_k = dtheta[:, k].unsqueeze(-1)       # (B, 1)
            
            # Optimization: only rotate if there's significant movement in the batch
            if theta_k.abs().max() < 1e-8:
                continue

            # Sample pivots and axes from CURRENT (partially updated) positions
            pivots  = pos_new[:, bi].unsqueeze(1)      # (B, 1, 3)
            ends    = pos_new[:, bj].unsqueeze(1)      # (B, 1, 3)
            axis_k  = ends - pivots                    # (B, 1, 3)
            axis_k  = axis_k / (axis_k.norm(dim=-1, keepdim=True) + 1e-8)

            # Batched Rodrigues for mask atoms
            rel     = pos_new[:, mask] - pivots        # (B, M, 3)
            
            cos_k   = theta_k.cos().unsqueeze(-1)      # (B, 1, 1)
            sin_k   = theta_k.sin().unsqueeze(-1)      # (B, 1, 1)
            
            # K_k for batched cross product
            K_k = torch.zeros(B, 3, 3, device=device)
            ax, ay, az = axis_k[:, 0, 0], axis_k[:, 0, 1], axis_k[:, 0, 2]
            K_k[:, 0, 1] = -az; K_k[:, 0, 2] =  ay
            K_k[:, 1, 0] =  az; K_k[:, 1, 2] = -ax
            K_k[:, 2, 0] = -ay; K_k[:, 2, 1] =  ax
            
            K_k2 = torch.bmm(K_k, K_k)
            I_k  = torch.eye(3, device=device).unsqueeze(0).expand(B, -1, -1)
            R_k  = I_k + sin_k * K_k + (1 - cos_k) * K_k2
            
            # Rotate all masked atoms for all batch members at once
            pos_new[:, mask] = torch.bmm(rel, R_k.transpose(1, 2)) + pivots

    return pos_new


# 
# 7. Energy-guided non-Gaussian interpolant  (EnFlow insight)
# 

def energy_guided_interpolant(
    pos_0:    torch.Tensor,   # (B, N, 3) noise sample
    pos_1:    torch.Tensor,   # (B, N, 3) target
    t:        float,
    phys_fn   = None,         # callable (pos)  energy (B,); if None  linear
) -> torch.Tensor:
    """
    Non-Gaussian interpolant path (EnFlow, 2025).

    Standard FM: pos(t) = (1-t)*pos_0 + t*pos_1
    Energy-guided: pos(t) = linear(t) - (t) * E(linear(t))

    where (t) =  * t*(1-t) vanishes at endpoints (boundary conditions intact).
    The energy correction bends the path toward low-energy regions,
    making the ODE straighter and reducing required integration steps.
    """
    pos_linear = (1.0 - t) * pos_0 + t * pos_1

    if phys_fn is None or t < 0.05 or t > 0.95:
        return pos_linear   # no correction at endpoints

    alpha = 0.05   # small correction coefficient (tunable)
    sigma_t = alpha * t * (1.0 - t)

    try:
        with torch.enable_grad():
            pos_mid = pos_linear.clone().detach().requires_grad_(True)
            e       = phys_fn(pos_mid)                    # (B,)
            grad_e  = torch.autograd.grad(e.sum(), pos_mid)[0]   # (B, N, 3)

        grad_e = torch.nan_to_num(grad_e, nan=0.0, posinf=5.0, neginf=-5.0)
        grad_e = grad_e.clamp(-5.0, 5.0)
        return pos_linear - sigma_t * grad_e.detach()
    except Exception as e:
        from logging import getLogger
        getLogger("SAEBFlow").error(f" [SAEB-Flow] Energy-guided interpolation failed: {e}. Falling back to linear.")
        return pos_linear   # fallback to linear on any error


# 
# 8. Fibre-bundle joint loss  (upgraded, vectorised)
# 

def compute_fiber_bundle_joint_loss(
    pos_proj: torch.Tensor,   # (B, N, 3)
    pos_ref:  torch.Tensor,   # (N, 3)
    fb:       FiberBundle,
) -> torch.Tensor:
    """
    Penalises inter-fragment bond deviations after fibre-bundle integration.

    This replaces both `compute_torsional_joint_loss` AND the separate
    Kabsch-post-hoc tearing correction.

    Vectorised over batch B and all NN pairs simultaneously.
    """
    dist_ref  = torch.cdist(pos_ref, pos_ref)               # (N, N)
    labels    = fb.fragment_labels
    diff_lbl  = labels.unsqueeze(0) != labels.unsqueeze(1)  # (N, N) bool
    joint_mask = (dist_ref < 1.8) & diff_lbl

    if joint_mask.sum() == 0:
        return torch.tensor(0.0, device=pos_proj.device)

    dist_proj_batch = torch.cdist(pos_proj, pos_proj)        # (B, N, N)
    drift = (dist_proj_batch[:, joint_mask] -
             dist_ref[joint_mask].unsqueeze(0)) ** 2         # (B, n_joints)
    loss  = drift.mean()
    return torch.clamp(loss, max=50.0)


# 
# Legacy API   backward-compatible wrappers for main file
# 

# Global cache: avoid rebuilding FiberBundle on every call
_fb_cache: dict = {}


def _get_or_build_fb(
    pos_native: torch.Tensor,
    labels:     torch.Tensor,
) -> FiberBundle:
    """
    Lazy-build FiberBundle from legacy (pos_native, labels) API.
    Cached by (N, device) key.
    """
    # Use a content-aware hash to prevent collision between ligands with same atom count
    pos_hash = hash(pos_native.view(-1).sum().item())
    key = (pos_native.shape[0], str(pos_native.device), pos_hash)
    if key not in _fb_cache:
        _fb_cache[key] = build_fiber_bundle(pos_native, n_fragments=int(labels.max().item()) + 1)
    return _fb_cache[key]


def get_rigid_fragments(
    pos_native: torch.Tensor,
    n_fragments: int = 4,
) -> torch.Tensor:
    """
    Legacy API: returns integer fragment labels (N,).
    Internally uses SAEB-Flow spectral clustering.
    """
    _, labels = _get_rotatable_bonds_spectral(pos_native, n_fragments)
    return labels


def sample_torsional_prior(
    pos_native:  torch.Tensor,
    labels:      torch.Tensor,
    p_center:    torch.Tensor,
    B:           int,
    noise_scale: float = 5.0,
) -> torch.Tensor:
    """
    Legacy API: calls saeb_harmonic_prior internally.
    """
    fb = _get_or_build_fb(pos_native, labels)
    return saeb_harmonic_prior(fb, pos_native, p_center, B, noise_scale)


def apply_fragment_kabsch(
    pos_pred: torch.Tensor,   # (B, N, 3)
    pos_ref:  torch.Tensor,   # (N, 3)
    labels:   torch.Tensor,   # (N,)
) -> torch.Tensor:
    """
    Replaces Kabsch snap with FK geodesic integration.
    The 'velocity' is computed as (pos_ref - pos_pred) / 1.0 (unit time).
    apply_saeb_step then integrates along the fibre bundle manifold,
    preserving bond lengths and avoiding SO(3) singularities.
    """
    fb      = _get_or_build_fb(pos_ref, labels)
    v_cart  = (pos_ref.unsqueeze(0) - pos_pred)   # (B, N, 3) pointing toward target

    # Single full step (dt=1.0: move all the way to target manifold-consistently)
    # In practice the training loop calls this with small dt via v_final_step.
    return apply_saeb_step(pos_pred, fb, v_cart, dt=1.0)


def compute_torsional_joint_loss(
    pos_projected: torch.Tensor,   # (B, N, 3)
    pos_ref:       torch.Tensor,   # (N, 3)
    labels:        torch.Tensor,   # (N,)
) -> torch.Tensor:
    """
    Legacy API: delegates to compute_fiber_bundle_joint_loss.
    """
    fb = _get_or_build_fb(pos_ref, labels)
    return compute_fiber_bundle_joint_loss(pos_projected, pos_ref, fb)


def clear_bundle_cache():
    """Call between experiments to free cached FiberBundle objects."""
    _fb_cache.clear()
