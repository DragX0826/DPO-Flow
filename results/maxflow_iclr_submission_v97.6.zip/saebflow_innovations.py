"""
saebflow_innovations.py — Complete Implementation

Resolves Bug 1 (Fatal Import Crash): Provides concrete implementations of
ShortcutFlowHead, ShortcutFlowLoss, shortcut_step, RecyclingEncoder,
run_with_recycling, sample_pocket_harmonic_prior, PHPDScheduler,
and integrate_innovations.

Design philosophy:
  - ShortcutFlowHead: Confidence-Bootstrapped Shortcut Flow (CBSF)
    Predicts both tangent velocity v AND direct x1 endpoint estimate,
    gated by per-atom confidence. High confidence → trust x1 shortcut.
    Low confidence → trust v_pred trajectory.
  - RecyclingEncoder: AlphaFold2-style iterative recycling.
    Encodes (previous_pos_L, previous_latent) into a correction signal
    injected at the embedding layer of the next recycle.
  - run_with_recycling: n-step iterative refinement wrapper.
  - PHPDScheduler: Physics-Harmonic Progressive Decay schedule for
    the anchor loss weight.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, Tuple, Optional


# ─────────────────────────────────────────────────────────────────────────────
# 1. ShortcutFlowHead
# ─────────────────────────────────────────────────────────────────────────────

class ShortcutFlowHead(nn.Module):
    """
    Confidence-Bootstrapped Shortcut Flow (CBSF) Head.

    Replaces the original SFMHead with a dual prediction:
      - v_pred:    tangent velocity (standard FM output)
      - x1_pred:   direct endpoint prediction (shortcut)
      - confidence: per-atom gate (0 = trust v_pred, 1 = trust x1_pred)

    At inference, the effective step is:
      new_pos = (1 - confidence) * (pos + v_pred*dt) + confidence * x1_pred
    """

    def __init__(self, hidden_dim: int):
        super().__init__()
        self.hidden_dim = hidden_dim

        # Velocity head (Equivariant tangent prediction)
        # Using a scalar gate to modulate the vector input
        self.v_norm  = nn.GroupNorm(min(8, hidden_dim // 8), hidden_dim)
        self.v_gate  = nn.Sequential(
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )
        # Vector projection to handle v_geom -> v_pred alignment
        self.v_proj  = nn.Linear(hidden_dim, 1, bias=False)

        # Endpoint shortcut head (Equivariant x1 prediction)
        self.x1_norm = nn.LayerNorm(hidden_dim)
        self.x1_gate = nn.Sequential(
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )

        # Confidence gate head (per-atom scalar in [0,1])
        self.conf_proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 4),
            nn.SiLU(),
            nn.Linear(hidden_dim // 4, 1),
            nn.Sigmoid()
        )

        # Curvature modulation (Curvature is a scalar property)
        self.curvature_gate = nn.Sequential(
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, h: torch.Tensor, v_geom: torch.Tensor = None, pos_L: torch.Tensor = None) -> Dict[str, torch.Tensor]:
        """
        h: (B*N, hidden_dim)
        v_geom: (B*N, 1, 3) or (B*N, K, 3) - Geometric vector features from GVP
        pos_L: (B*N, 3) or (B, N, 3) - Current absolute positions (optional)
        Returns dict with:
          v_pred:     (B*N, 3)
          x1_pred:    (B*N, 3)  - Absolute endpoint prediction
          confidence: (B*N, 1)
        """
        # Velocity
        h_v     = self.v_norm(h)
        # Equivariant v_pred: Scale vector features by scalar importance
        # If v_geom is provided (from GVP), use it as the basis for v_pred.
        if v_geom is not None:
            # v_geom: (B*N, K, 3)
            # v_importance: (B*N, K) from h - Scalar weights for vectors
            # Pure Directional Equivariance:
            # The direction is a weighted sum of input geometric vectors.
            v_importance = torch.sigmoid(self.v_proj(h_v)).unsqueeze(-1) # (B*N, 1, 1) assuming K=1 for now
            v_pred = (v_geom * v_importance).sum(dim=1) # (B*N, 3)
        else:
            # Fallback to scalar-derived vectors (only for non-equi legacy path)
            # This is what was causing the zero alignment.
            v_pred = torch.zeros(h.size(0), 3, device=h.device)
            v_pred[:, 0] = 0.01 # Minimal break-symmetry
            
        gate    = self.curvature_gate(h)          # (B*N, 1)
        v_pred  = v_pred * gate                   # (B*N, 3)

        # Endpoint shortcut (x1_pred) - Defined as delta from pos_L
        x1_gate = self.x1_gate(h)
        x1_base = torch.zeros_like(v_pred)
        if v_geom is not None:
             x1_base = v_geom[:, 0] # Use first principal vector as direction proxy
        
        # Semantic alignment: x1_pred = base_pos + gated_delta
        delta_x1 = x1_base * x1_gate
        if pos_L is not None:
            x1_pred = pos_L.view(-1, 3) + delta_x1
        else:
            x1_pred = delta_x1

        # Confidence gate
        confidence = self.conf_proj(h)            # (B*N, 1)

        return {
            'v_pred':     v_pred,
            'x1_pred':    x1_pred,
            'confidence': confidence,
        }


# ─────────────────────────────────────────────────────────────────────────────
# 2. ShortcutFlowLoss
# ─────────────────────────────────────────────────────────────────────────────

class ShortcutFlowLoss(nn.Module):
    """
    CBSF compound loss combining:
      L_fm:   Huber( v_pred, v_target )
      L_x1:   confidence-weighted Huber( x1_pred, pos_native )
      L_conf: entropy regularisation so confidence doesn't collapse to 0 or 1
    """

    def __init__(self, lambda_x1: float = 1.0, lambda_conf: float = 0.01):
        super().__init__()
        self.lambda_x1   = lambda_x1
        self.lambda_conf = lambda_conf

    def forward(
        self,
        v_pred:     torch.Tensor,   # (B, N, 3)
        x1_pred:    torch.Tensor,   # (B, N, 3)
        confidence: torch.Tensor,   # (B*N, 1) or (B, N, 1)
        v_target:   torch.Tensor,   # (B, N, 3)
        pos_native: torch.Tensor,   # (N, 3)
        B: int,
        N: int,
    ) -> Tuple[torch.Tensor, Dict]:

        # Reshape confidence → (B, N, 1)
        if confidence.dim() == 2:
            conf_b = confidence.view(B, N, 1)
        else:
            conf_b = confidence.view(B, N, 1)

        # L_fm: standard flow matching
        loss_fm = F.huber_loss(v_pred, v_target, delta=1.0)

        # L_x1: shortcut endpoint loss (confidence-weighted)
        native_b   = pos_native.unsqueeze(0).expand(B, -1, -1)   # (B, N, 3)
        x1_err     = F.huber_loss(x1_pred, native_b, delta=1.0, reduction='none')   # (B, N, 3)
        loss_x1    = (conf_b * x1_err).mean()

        # L_conf: entropy reg (pushes confidence away from extremes)
        eps       = 1e-6
        conf_clip = conf_b.clamp(eps, 1 - eps)
        loss_conf = -(conf_clip * conf_clip.log() +
                      (1 - conf_clip) * (1 - conf_clip).log()).mean()

        total = loss_fm + self.lambda_x1 * loss_x1 - self.lambda_conf * loss_conf

        metrics = {
            'loss_fm':   loss_fm.item(),
            'loss_x1':   loss_x1.item(),
            'loss_conf': loss_conf.item(),
            'mean_conf': conf_b.mean().item(),
        }
        return total, metrics


# ─────────────────────────────────────────────────────────────────────────────
# 3. shortcut_step
# ─────────────────────────────────────────────────────────────────────────────

def shortcut_step(
    pos_L:      torch.Tensor,   # (B, N, 3) current positions
    v_pred:     torch.Tensor,   # (B, N, 3) tangent velocity
    x1_pred:    torch.Tensor,   # (B, N, 3) endpoint shortcut
    confidence: torch.Tensor,   # (B*N, 1) or (B, N, 1)
    t:          float,
    dt:         float,
) -> torch.Tensor:
    """
    Confidence-blended position update.
    new_pos = (1 - conf) * euler_step + conf * shortcut_step
    """
    B, N, _ = pos_L.shape

    if confidence.dim() == 2:
        conf_b = confidence.view(B, N, 1)
    else:
        conf_b = confidence.view(B, N, 1)

    euler    = pos_L + v_pred * dt                    # standard Euler
    shortcut = pos_L + (x1_pred - pos_L) * dt / max(1 - t, 1e-3)   # warp to x1

    return (1 - conf_b) * euler + conf_b * shortcut


# ─────────────────────────────────────────────────────────────────────────────
# 4. RecyclingEncoder
# ─────────────────────────────────────────────────────────────────────────────

class RecyclingEncoder(nn.Module):
    """
    AlphaFold2-style iterative recycling encoder.

    Takes (prev_pos_L, prev_latent) and produces a correction signal
    that is ADDED to the ligand embedding at the start of the next recycle.

    Prev positions are encoded via distance bucketing (like AF2 pair features),
    prev latents are projected via a small MLP.
    """

    def __init__(self, hidden_dim: int, n_dist_bins: int = 15):
        super().__init__()
        self.hidden_dim  = hidden_dim
        self.n_dist_bins = n_dist_bins

        # Distance bin boundaries (0 → 10 Å in 15 bins)
        bins = torch.linspace(0.0, 10.0, n_dist_bins + 1)
        self.register_buffer('dist_bins', bins)

        # Pair feature encoder: dist_bin_OH + h_i + h_j → correction
        self.pair_enc = nn.Sequential(
            nn.Linear(n_dist_bins + hidden_dim * 2, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(
        self,
        prev_pos_L: torch.Tensor,    # (B, N, 3)
        prev_latent: torch.Tensor,   # (B*N, H) or (B, N, H)
    ) -> torch.Tensor:
        """Returns correction: (B*N, hidden_dim)"""
        B, N, _ = prev_pos_L.shape
        H       = self.hidden_dim

        # Distance matrix: (B, N, N)
        dist    = torch.cdist(prev_pos_L, prev_pos_L).clamp(max=10.0)

        # Bin the distances
        bin_idx = torch.bucketize(dist, self.dist_bins[1:-1])   # (B, N, N)
        dist_oh = F.one_hot(bin_idx, num_classes=self.n_dist_bins).float()   # (B, N, N, D_bin)

        # Latent features
        if prev_latent.dim() == 2:
            h = prev_latent.view(B, N, H)
        else:
            h = prev_latent

        h_i = h.unsqueeze(2).expand(-1, -1, N, -1)   # (B, N, N, H)
        h_j = h.unsqueeze(1).expand(-1, N, -1, -1)   # (B, N, N, H)

        # Pair encoder: (B, N, N, D_bin+2H) → (B, N, N, H)
        pair_in  = torch.cat([dist_oh, h_i, h_j], dim=-1)
        pair_out = self.pair_enc(pair_in)                        # (B, N, N, H)

        # Aggregate over j dimension → node correction (B, N, H)
        correction = pair_out.mean(dim=2)
        correction = self.norm(correction)

        return correction.view(B * N, H)


# ─────────────────────────────────────────────────────────────────────────────
# 5. run_with_recycling
# ─────────────────────────────────────────────────────────────────────────────

def run_with_recycling(
    model,
    recycling_encoder: RecyclingEncoder,
    *,
    pos_L:   torch.Tensor,
    x_L:     torch.Tensor,
    x_P:     torch.Tensor,
    pos_P:   torch.Tensor,
    h_P:     torch.Tensor,
    t_flow:  torch.Tensor,
    n_recycle: int = 3,
) -> Dict[str, torch.Tensor]:
    """
    Iterative recycling wrapper.
    On each iteration (except the first), inject the recycling correction
    into x_L by patching the backbone's embedding layer output.

    To avoid modifying the backbone signature, we use a forward hook.
    """
    B, N, D = x_L.shape
    correction = None

    for i in range(n_recycle):
        if correction is not None:
            # Inject correction into x_L latent channel (last hidden_dim dims)
            H    = correction.shape[-1]
            x_L_ = x_L.clone()
            # Add recycling signal into the last H dims of x_L
            # (these are overwritten by the model's embedding layer,
            #  so we use a side-channel approach via x_L padding)
            # Practical approach: use a hook on the embedding layer
            hook_correction = correction.detach().view(B, N, H)
        else:
            hook_correction = None

        # ── forward hook to inject recycling correction ──────────────────
        handle = None
        if hook_correction is not None and hasattr(model, 'model'):
            backbone = model.model
            if hasattr(backbone, 'embedding'):
                def _hook(module, input, output, corr=hook_correction):
                    # output: (B*N, H)  corr: (B, N, H)
                    H_ = min(output.shape[-1], corr.shape[-1])
                    _BN = output.shape[0]
                    _B  = corr.shape[0]
                    _N  = _BN // _B
                    corr_flat = corr.view(_BN, -1)[:, :H_]
                    return output + 0.1 * corr_flat
                handle = backbone.embedding.register_forward_hook(_hook)

        out = model(
            t_flow  = t_flow,
            pos_L   = pos_L,
            x_L     = x_L,
            x_P     = x_P,
            pos_P   = pos_P,
            h_P     = h_P,
        )

        if handle is not None:
            handle.remove()

        # Prepare recycling inputs for next iteration
        # Update pos_L with the shortcut prediction (detached, no grad)
        with torch.no_grad():
            dt_recycle = 1.0 / n_recycle
            t_val      = t_flow[0].item() if t_flow.numel() > 0 else 0.0

            if 'x1_pred' in out and 'confidence' in out:
                # Maintain pos_L connectivity for Jacobian Reg.
                # Only detach v_pred/x1_pred/conf to avoid massive graph growth,
                # but keep the base pos_L connected.
                pos_L_next = shortcut_step(
                    pos_L,
                    out['v_pred'].view(B, N, 3).detach(),
                    out['x1_pred'].view(B, N, 3).detach(),
                    out['confidence'].detach(),
                    t=t_val, dt=dt_recycle,
                )
            else:
                pos_L_next = pos_L + out['v_pred'].view(B, N, 3).detach() * dt_recycle

            pos_L = pos_L_next   # Always update for the next model evaluation or final return

            if i < n_recycle - 1:
                correction = recycling_encoder(
                    pos_L.detach(),
                    out['latent'].detach(),
                )

    return out


# ─────────────────────────────────────────────────────────────────────────────
# 6. sample_pocket_harmonic_prior
# ─────────────────────────────────────────────────────────────────────────────

def sample_pocket_harmonic_prior(
    pos_native:  torch.Tensor,    # (N, 3)
    pocket_center: torch.Tensor,  # (3,)
    B: int,
    noise_scale: float = 5.0,
) -> torch.Tensor:
    """
    Physics-Harmonic Pocket Prior (PHPD).
    Places ligand copies in the pocket with noise drawn from a
    harmonic potential centred on the pocket:
      x_i ~ N(pocket_center, (noise_scale * d_i)^2 I)
    where d_i is the distance of atom i from the ligand centroid.
    Atoms further from the centroid get MORE noise → wider search near periphery.
    """
    device = pos_native.device
    N      = pos_native.shape[0]
    com    = pos_native.mean(dim=0)

    # Per-atom distance from COM → noise scale
    d_i   = (pos_native - com).norm(dim=-1, keepdim=True)     # (N, 1)
    sigma = (noise_scale * 0.1 + noise_scale * 0.9 * d_i / (d_i.max() + 1e-6))   # (N, 1)

    batch = []
    for _ in range(B):
        noise    = torch.randn(N, 3, device=device) * sigma
        pos_b    = pocket_center.unsqueeze(0) + noise
        batch.append(pos_b)

    return torch.stack(batch, dim=0)   # (B, N, 3)


# ─────────────────────────────────────────────────────────────────────────────
# 7. PHPDScheduler
# ─────────────────────────────────────────────────────────────────────────────

class PHPDScheduler:
    """
    Physics-Harmonic Progressive Decay scheduler.
    Controls the anchor loss weight over training:
      phase 1 (t < 0.3):  high anchor (10000 → hold ligand near pocket)
      phase 2 (0.3–0.7):  linear decay (10000 → 500)
      phase 3 (t > 0.7):  low anchor (500 → fine precision)
    """

    def __init__(self, w_high: float = 10000.0, w_low: float = 500.0):
        self.w_high = w_high
        self.w_low  = w_low

    def get_weight(self, progress: float) -> float:
        if progress < 0.3:
            return self.w_high
        elif progress < 0.7:
            p = (progress - 0.3) / 0.4
            return self.w_high * (1.0 - p) + self.w_low * p
        else:
            return self.w_low


# ─────────────────────────────────────────────────────────────────────────────
# 8. integrate_innovations
# ─────────────────────────────────────────────────────────────────────────────

def integrate_innovations(config, backbone, device) -> Dict:
    """
    Constructs and wires together all innovation components.

    Returns a dict containing:
      recycling_encoder:  RecyclingEncoder instance
      shortcut_loss_fn:   ShortcutFlowLoss instance
      phpd_scheduler:     PHPDScheduler instance
    """
    hidden_dim = 64   # matches SAEBFlowBackbone default

    recycling_encoder = RecyclingEncoder(hidden_dim=hidden_dim).to(device)
    shortcut_loss_fn  = ShortcutFlowLoss(lambda_x1=1.0, lambda_conf=0.01).to(device)
    phpd_scheduler    = PHPDScheduler()

    return {
        'recycling_encoder': recycling_encoder,
        'shortcut_loss_fn':  shortcut_loss_fn,
        'phpd_scheduler':    phpd_scheduler,
    }
