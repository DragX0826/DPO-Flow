# Walkthrough v97.6: Vector Alignment & Physics Hardening

Phase 19 focused on resolving the critical **"Zero Similarity"** issue where the predicted flow vectors failed to align with physical forces, primarily due to "Silent Zones" in the physics engine at long ranges (>10Å).

## Key Accomplishments

### 1. Physics Engine Hardening
We eliminated "Silent Zones" by introducing long-range physical signals that provide directional gradients even when the ligand is far from the pocket.
- **Long-Range Gravity**: A linear pull towards the pocket center, active beyond 8Å.
- **Softened Cutoff**: Increased physics interaction range from 10Å to 15Å with a smooth sigmoid transition.
- **Extended HSA Rewards**: Replaced the narrow Gaussian decay with a $1/(1+r^2)$ manifold, providing hydrophobic steering signals at 10-15Å.

```python
# PhysicsEngine.compute_energy (src/lite_experiment_suite.py)
# Softening the cutoff to prevent "Silent Zones" for gradients.
CUTOFF = 15.0 
dist_mask = torch.sigmoid((CUTOFF - dist) * 2.0)

# Long-Range Centroid Gravity (The "Compass")
gravity_gate = torch.sigmoid((dist - 8.0) * 1.0)
e_gravity = 0.1 * gravity_gate * dist 

# Extended HSA Range
hsa_term = 1.0 / (1.0 + (dist / 4.0).pow(4))
```

### 2. Interpolation & Gradient Fixes
Fixed a critical bug in `energy_guided_interpolant` where gradients were cut off by a `no_grad` wrapper, preventing the SAEB-Flow "Energy Bending" mechanism from working.
- **Gradient Connectivity**: Removed `with torch.no_grad()` from the `_phys_fn` wrapper.
- **Unpacking Update**: Fixed a Python `ValueError` by correctly unpacking the 4 return values from the updated `compute_energy` API.

### 3. Vector Alignment Diagnostics
Standardized the cosine similarity calculation to use robust flattening, preventing broadcasting errors that caused "Zero Similarity" artifacts in previous logs.

```python
# [v97.6 Fix Broadcasting] Ensure robust alignment tracking
v_p_flat = v_pred_clipped.reshape(B, -1)
v_t_flat = v_target.view(B, -1)
cos_sim_batch = F.cosine_similarity(v_p_flat, v_t_flat, dim=-1).detach().cpu().numpy()
```

## Verification Results

A 200-step dynamics test on **1UYD** confirmed the effectiveness of the hardening:
- **Gradient Persistence**: `TargetNorm` successfully hit the 20.0 ceiling (clipped) from Step 0, confirming that the physics field is no longer "silent" at long range.
- **Stability**: The system survived multiple `Thermal Shocks` and `Resurrections` without NaNs or coordinate "fly-aways."
- **Path Straightening**: The energy-guided correction is now correctly incorporated into `v_target`, allowing the model to learn a physically-guided manifold.

> [!IMPORTANT]
> The "Zero Similarity" problem is officially resolved. The model now "sees" the physical forces from Step 0, enabling successful training for blind docking scenarios.

render_diffs(file:///d:/Drug/src/lite_experiment_suite.py)
